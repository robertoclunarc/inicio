export default interface solpedtrazaModelo {
    idTrazaSolped? : number, 
	fechaAlta? : any, 
	justificacion? : string, 
	idSolpedCompras? : number, 
	idEstadoSolped? : number, 
	estadoActual? : string, 
	idSegUsuario? : number, 
	estadoAnterior? : string
}