export default interface solped {
    idSolpedCompras?: number, 
	fechaAlta?:string, 
	fechaAOrdenC?:any, 
	descripcion? : any, 
	idTicketServicio? : any, 
	idEstadoActual? : any, 
	estadoActual? :any, 
	idSolpedPadre?: number, 
	idConfigGerencia? :number, 
	idAdmActivo?: number,
	idSegUsuario?: number
}