export default interface OrdenCompraModelo {
    idComprasOC?: number, 
	fechaAlta? : any, 
	observaciones? : string, 
	idProveedor? :number, 
	idAdmActivo? : number, 
	IdComprasEmpresa? : number, 
	idSolpedCompras? : number, 
	monto_total? : number, 
	condiciones? :string, 
	formas_envio? : string, 
	idConfigGerencia? : number
}